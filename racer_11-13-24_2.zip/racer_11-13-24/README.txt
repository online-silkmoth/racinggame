racer is a small racing game where you play as like a cybertruck maybe

CONTROLS
UP - Forwards
DOWN - Backwards
LEFT/RIGHT - Turning
SPACE - Brake

TAB - Reset room
ESC - Return to the main menu

OPTIONS
Debug - allows for debug features to be visible
High Bounce - Changes how bounce speed is calculated when bouncing off walls
	Divide - Default, car loses half it's speed when hitting a wall
	Add - Car gains 2 units of speed when hitting a wall
	Multiply - The car's speed doubles when hitting a wall (USE WITH CAUTION)
Explosion SFX - Toggles between the DELTARUNE explosion sound and the Vine Boom
Meme Flash - Replaces the normal DELTARUNE explosion sprite with an image of a totaled cybertruck that fades over time